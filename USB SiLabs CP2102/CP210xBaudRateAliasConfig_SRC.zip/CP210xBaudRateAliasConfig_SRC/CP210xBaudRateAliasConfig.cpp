// CP210xBaudRateAliasConfig.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CP210xBaudRateAliasConfig.h"
#include "CP210xBaudRateAliasConfigDlg.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigApp

BEGIN_MESSAGE_MAP(CCP210xBaudRateAliasConfigApp, CWinApp)
	//{{AFX_MSG_MAP(CCP210xBaudRateAliasConfigApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigApp construction

CCP210xBaudRateAliasConfigApp::CCP210xBaudRateAliasConfigApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCP210xBaudRateAliasConfigApp object

CCP210xBaudRateAliasConfigApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigApp initialization

BOOL CCP210xBaudRateAliasConfigApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CCP210xBaudRateAliasConfigDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

UINT HexStringToValue(CString s, int size)
{
	//this function takes a hex string, and converts it
	//to a value
	
	UINT val = 0;

	s.TrimLeft();
	s.TrimRight();
	
	for (int i = s.GetLength(); i < size; i++)
	{
		s = '0' + s;
	}

	for (i = 0; i < size; i++)
	{
		switch (s.GetAt((size-1)-i))
		{
		case '0' : val += 0*pow(16,i); break;
		case '1' : val += 1*pow(16,i); break;
		case '2' : val += 2*pow(16,i); break;
		case '3' : val += 3*pow(16,i); break;
		case '4' : val += 4*pow(16,i); break;
		case '5' : val += 5*pow(16,i); break;
		case '6' : val += 6*pow(16,i); break;
		case '7' : val += 7*pow(16,i); break;
		case '8' : val += 8*pow(16,i); break;
		case '9' : val += 9*pow(16,i); break;
		case 'A' : val += 10*pow(16,i); break;
		case 'B' : val += 11*pow(16,i); break;
		case 'C' : val += 12*pow(16,i); break;
		case 'D' : val += 13*pow(16,i); break;
		case 'E' : val += 14*pow(16,i); break;
		case 'F' : val += 15*pow(16,i); break;
		}
	}

	return val;
}

WORD CalculateBestBaudGen(UINT sysclk, UINT br)
{
	//This method checks eight baudrates, a low and high for each 4 prescalers.
	//It then picks the closest baudrate possible.

	WORD prescale[4] = {1, 4, 12, 48}, baudgen[4][2];
	UINT tbr[4][2];
	
	// Loop through each of the 4 prescalers
	for (int i = 0; i < 4; i++)
	{
		// Calculate the baudgen
		baudgen[i][0] = CalculateBaudGen(CP2102_SYSCLK, prescale[i], br);
		// Calculate the baudrate
		tbr[i][0] = CalculateBaudRate(CP2102_SYSCLK, prescale[i], baudgen[i][0]);
		// If the baud rate is greater than our desired, use the baud gen - 1 to find the other
		// otherwise, add 1 to the baud gen to get the greater baudrate
		if (tbr[i][0] >= br)
			baudgen[i][1] = baudgen[i][0] - 1;
		else
			baudgen[i][1] = baudgen[i][0] + 1;
		// Use the new baudgen to calculate the next baudrate
		tbr[i][1] = CalculateBaudRate(CP2102_SYSCLK, prescale[i], baudgen[i][1]);
	}

	int indexi = 0, indexj = 0;
	int space = abs((int)(tbr[0][0] - br));

	// Loop through each of the 4 prescales and 2 baud rates for each prescale, and
	// choose the one with the least space between then desired and actual baudrates
	for (i = 0; i < 4; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			if (space > abs((int)(tbr[i][j] - br)))
			{
				indexi = i;
				indexj = j;
				space = abs((int)(tbr[i][j] - br));
			}
		}
	}

	// Return that baudgen
	return baudgen[indexi][indexj];
}

BYTE CalculateBestPrescaler(UINT sysclk, UINT br)
{
	//This method checks eight baudrates, a low and high for each 4 prescalers.
	//It then picks the closest baudrate possible.
	WORD prescale[4] = {1, 4, 12, 48}, baudgen[4][2];
	UINT tbr[4][2];
	
	// Loop through each of the 4 prescalers
	for (int i = 0; i < 4; i++)
	{
		// Calculate the baudgen
		baudgen[i][0] = CalculateBaudGen(CP2102_SYSCLK, prescale[i], br);
		// Calculate the baudrate
		tbr[i][0] = CalculateBaudRate(CP2102_SYSCLK, prescale[i], baudgen[i][0]);
		// If the baud rate is greater than our desired, use the baud gen - 1 to find the other
		// otherwise, add 1 to the baud gen to get the greater baudrate
		if (tbr[i][0] >= br)
			baudgen[i][1] = baudgen[i][0] - 1;
		else
			baudgen[i][1] = baudgen[i][0] + 1;
		// Use the new baudgen to calculate the next baudrate
		tbr[i][1] = CalculateBaudRate(CP2102_SYSCLK, prescale[i], baudgen[i][1]);
	}

	int indexi = 0, indexj = 0;
	int space = abs((int)(tbr[0][0] - br));

	// Loop through each of the 4 prescales and 2 baud rates for each prescale, and
	// choose the one with the least space between then desired and actual baudrates
	for (i = 0; i < 4; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			if (space > abs((int)(tbr[i][j] - br)))
			{
				indexi = i;
				indexj = j;
				space = abs((int)(tbr[i][j] - br));
			}
		}
	}

	// Return that prescale
	return prescale[indexi];
}

UINT CalculateBaudRate(UINT sysclk, WORD prescaler, WORD baudgen)
{
	// To get a rounded baud rate, round to the UINT the acutual baud rate
	return RoundUint(CalculateActualBaudRate(sysclk, prescaler, baudgen));
}

double CalculateActualBaudRate(UINT sysclk, WORD prescaler, WORD baudgen)
{
	// Catch divide by 0 errors
	if (prescaler == 0) return 0.0;

	// Actual baud rate calculation
	double br = (sysclk / prescaler);
	return (br / ((double)2 * (double)((double)65536 - (double)baudgen)));
}

WORD CalculateBaudGen(UINT sysclk, WORD prescaler, UINT br)
{
	// Catch divide by 0 errors
	if (prescaler == 0) return 0.0;
	if (br == 0) return 0.0;

	// Baud gen calculation, round the result and return
	double baudgen = ((double)65536 - (double)((double)((double)sysclk / (double)prescaler) / (double)(2 * br)));
	return RoundWord(baudgen);
}

WORD CalculateTimer0Reload(UINT timer0sysclk, double br)
{
	// Timer 0 reload calculation, just return the value, and it will round down always
	double timer0reload = ((double)65536 - (double)((double)timer0sysclk * (double)((double)18 / (double)br)));
	return timer0reload;
}

double CalculateTimeoutTime(UINT timer0sysclk, WORD reload)
{
	// Catch divide by 0 errors
	if (timer0sysclk == 0) return 0.0;

	// Timeout time calculation, if it is greater than 1.0, then simply just return 1.0
	double time = ((double)(65536 - reload) * ((double)1 / (double)timer0sysclk)) * (double)1000;
	if (time > 1.0)
		return 1.0;
	else
		return time;
}

WORD RoundWord(double val)
{
	if (val - floor(val) >= .5)
		return (WORD)ceil(val);
	else
		return (WORD)floor(val);
}

UINT RoundUint(double val)
{
	if (val - floor(val) >= .5)
		return (UINT)ceil(val);
	else
		return (UINT)floor(val);
}