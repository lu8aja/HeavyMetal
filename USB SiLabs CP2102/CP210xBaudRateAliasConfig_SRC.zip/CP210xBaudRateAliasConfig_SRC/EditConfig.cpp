// EditConfig.cpp : implementation file
//

#include "stdafx.h"
#include "CP210xBaudRateAliasConfig.h"
#include "EditConfig.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditConfig dialog


CEditConfig::CEditConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CEditConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditConfig)
	m_BaudGen = _T("");
	m_LineNum = _T("");
	m_Timer0Reload = _T("");
	m_BaudRateDBR = 0;
	m_BaudRateABR = 0;
	m_DefaultBaudGen = _T("");
	m_DefaultPrescaler = _T("");
	m_DefaultTimer0Reload = _T("");
	m_DefaultTimeout = _T("");
	m_Timeout = _T("");
	m_Override = FALSE;
	//}}AFX_DATA_INIT
}


void CEditConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditConfig)
	DDX_Control(pDX, IDC_COMBO_PRESCALER, m_PrescalerList);
	DDX_Text(pDX, IDC_EDIT_BAUDGEN, m_BaudGen);
	DDV_MaxChars(pDX, m_BaudGen, 4);
	DDX_Text(pDX, IDC_STATIC_LINENUM, m_LineNum);
	DDX_Text(pDX, IDC_EDIT_T0RELOAD, m_Timer0Reload);
	DDV_MaxChars(pDX, m_Timer0Reload, 4);
	DDX_Text(pDX, IDC_EDIT_BAUDRATE_DBR, m_BaudRateDBR);
	DDV_MinMaxUInt(pDX, m_BaudRateDBR, 1, 24000000);
	DDX_Text(pDX, IDC_EDIT_BAUDRATE_ABR, m_BaudRateABR);
	DDX_Text(pDX, IDC_EDIT_DEFAULTBAUDGEN, m_DefaultBaudGen);
	DDX_Text(pDX, IDC_EDIT_DEFAULTPRESCALER, m_DefaultPrescaler);
	DDX_Text(pDX, IDC_EDIT_DEFAULTT0RELOAD, m_DefaultTimer0Reload);
	DDX_Text(pDX, IDC_EDIT_DEFAULTTIMEOUT, m_DefaultTimeout);
	DDX_Text(pDX, IDC_EDIT_TIMEOUT, m_Timeout);
	DDX_Check(pDX, IDC_CHECK_OVERRIDE, m_Override);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditConfig, CDialog)
	//{{AFX_MSG_MAP(CEditConfig)
	ON_BN_CLICKED(IDC_BUTTON_ADVANCED, OnButtonAdvanced)
	ON_EN_CHANGE(IDC_EDIT_BAUDRATE_DBR, OnChangeEditBaudrateDbr)
	ON_BN_CLICKED(IDC_CHECK_OVERRIDE, OnCheckOverride)
	ON_EN_CHANGE(IDC_EDIT_BAUDGEN, OnChangeEditBaudgen)
	ON_CBN_SELCHANGE(IDC_COMBO_PRESCALER, OnSelchangeComboPrescaler)
	ON_EN_CHANGE(IDC_EDIT_T0RELOAD, OnChangeEditT0reload)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditConfig message handlers

BOOL CEditConfig::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	// Position the window so that it fits in the parent wnd even when "advanced"
	// is clicked
	CRect thisRect, mainRect;
	GetWindowRect(&thisRect);
	AfxGetMainWnd()->GetWindowRect(&mainRect);
	SetWindowPos(NULL, ((mainRect.left + ((mainRect.right - mainRect.left) / 2)) - ((thisRect.right - thisRect.left) * 0.5)), ((mainRect.top + ((mainRect.bottom - mainRect.top) * 0.5)) - (ADVANCED_HEIGHT / 2)), thisRect.right - thisRect.left, 145, SWP_NOZORDER | SWP_SHOWWINDOW);

	// If we are overriding, then enable the user entry fields and click the on advanced
	// button to show the fields to the user automatically
	if (m_Override)
	{
		GetDlgItem(IDC_EDIT_BAUDGEN)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_PRESCALER)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_T0RELOAD)->EnableWindow(true);
		switch (m_Prescaler)
		{
		case 1 : m_PrescalerList.SetCurSel(0);	break;
		case 4 : m_PrescalerList.SetCurSel(1);	break;
		case 12 : m_PrescalerList.SetCurSel(2);	break;
		case 48 : m_PrescalerList.SetCurSel(3);	break;
		}
		OnButtonAdvanced();
	}

	// Update all data in the window
	UpdateAllData();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditConfig::UpdateAllData()
{
	// Read in any new values from the window
	UpdateData(TRUE);

	// Use the desired baud rate field to determine the default data and display it in the window
	DetermineAndUpdateDefaultBaudRate(CP2102_SYSCLK, m_BaudRateDBR);
	
	// If we are overriding, then calculate the baudrate using user entry fields, otherwise
	// just use the default data fields
	if (m_Override)
		m_BaudRateABR = CalculateBaudRate(CP2102_SYSCLK, m_Prescaler, HexStringToValue(m_BaudGen, m_BaudGen.GetLength()));
	else
		m_BaudRateABR = CalculateBaudRate(CP2102_SYSCLK, m_Prescaler, HexStringToValue(m_DefaultBaudGen, m_DefaultBaudGen.GetLength()));

	// Update all the timeouts based on our current data
	DetermineAndUpdateDefaultTimeout();

	// Update the times of the current timeouts based on the timer 0 reload val
	UpdateTimeoutTimes();

	// Write all the new values to the window
	UpdateData(FALSE);
}

void CEditConfig::DetermineAndUpdateDefaultBaudRate(UINT sysclk, UINT br)
{
	// Store the baud rate reload value and prescale of the corrsponding baudrate
	// into the default fields.
	m_DefaultBaudGen.Format("%04X", CalculateBestBaudGen(sysclk, br));
	m_DefaultPrescaler.Format("%d", CalculateBestPrescaler(sysclk, br));

	// If we are not overriding, then store our default values in the override section as
	// well
	if (!m_Override)
	{
		m_BaudGen = m_DefaultBaudGen;
		m_Prescaler = CalculateBestPrescaler(sysclk, br);

		switch (m_Prescaler)
		{
		case 1 : m_PrescalerList.SetCurSel(0);	break;
		case 4 : m_PrescalerList.SetCurSel(1);	break;
		case 12 : m_PrescalerList.SetCurSel(2);	break;
		case 48 : m_PrescalerList.SetCurSel(3);	break;
		}
	}

	// Update window with new values
	UpdateData(FALSE);
}

void CEditConfig::DetermineAndUpdateDefaultTimeout()
{
	// Update the default timer reload based on an actual calculation of the baud rate
	m_DefaultTimer0Reload.Format("%04X", CalculateTimer0Reload(CP2102_TIMEOUT_CLOCK, CalculateActualBaudRate(CP2102_SYSCLK, atoi(m_DefaultPrescaler), HexStringToValue(m_DefaultBaudGen, m_DefaultBaudGen.GetLength()))));
	
	// If we are not overriding then store it in the user fields as well
	if (!m_Override)
	{
		m_Timer0Reload = m_DefaultTimer0Reload;
	}

	// Update window with new values
	UpdateData(FALSE);
}

void CEditConfig::UpdateTimeoutTimes()
{
	// Update both timeout times based on their current values
	m_DefaultTimeout.Format("%5.4f", CalculateTimeoutTime(CP2102_TIMEOUT_CLOCK, HexStringToValue(m_DefaultTimer0Reload, m_DefaultTimer0Reload.GetLength())));
	m_Timeout.Format("%5.4f", CalculateTimeoutTime(CP2102_TIMEOUT_CLOCK, HexStringToValue(m_Timer0Reload, m_Timer0Reload.GetLength())));

	// Update window with new values
	UpdateData(FALSE);
}

void CEditConfig::OnButtonAdvanced() 
{
	// TODO: Add your control notification handler code here
	
	// Expand the window based on the setting of the advanced button
	CRect thisRect, mainRect;
	CString status;
	GetWindowRect(&thisRect);
	AfxGetMainWnd()->GetWindowRect(&mainRect);
	GetDlgItem(IDC_BUTTON_ADVANCED)->GetWindowText(status);
	if (status == "Advanced  >")
	{   
		GetDlgItem(IDC_BUTTON_ADVANCED)->SetWindowText("Advanced  <");
		SetWindowPos(NULL, 0, 0, thisRect.right - thisRect.left, ADVANCED_HEIGHT, SWP_NOMOVE | SWP_NOREPOSITION | SWP_NOZORDER);
	}
	else
	{
		GetDlgItem(IDC_BUTTON_ADVANCED)->SetWindowText("Advanced  >");
		SetWindowPos(NULL, 0, 0, thisRect.right - thisRect.left, NO_ADVANCED_HEIGHT, SWP_NOMOVE | SWP_NOREPOSITION | SWP_NOZORDER);
	}
}

void CEditConfig::OnChangeEditBaudrateDbr() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here

	// To avoid the auto error check from going off in a blank window, dont update data
	// unless we have check ourselves for basic things
	CString tmp;
	GetDlgItem(IDC_EDIT_BAUDRATE_DBR)->GetWindowText(tmp);
	tmp.TrimLeft();
	tmp.TrimRight();
	if (tmp.GetLength() != 0)
		if ((atoi(tmp) < 24000001) && atoi(tmp) > 0)
			if (UpdateData(TRUE))
				if (m_BaudRateDBR > 0)
					UpdateAllData();
}

void CEditConfig::OnCheckOverride() 
{
	// TODO: Add your control notification handler code here
	
	// Get all current data from the window
	UpdateData(TRUE);

	// If we are overriding then enable the user input fields, otherwise
	// disable the user input fields and update all data to set them back to default
	if (m_Override)
	{
		GetDlgItem(IDC_EDIT_BAUDGEN)->EnableWindow(true);
		GetDlgItem(IDC_COMBO_PRESCALER)->EnableWindow(true);
		GetDlgItem(IDC_EDIT_T0RELOAD)->EnableWindow(true);
	}
	else
	{
		GetDlgItem(IDC_EDIT_BAUDGEN)->EnableWindow(false);
		GetDlgItem(IDC_COMBO_PRESCALER)->EnableWindow(false);
		GetDlgItem(IDC_EDIT_T0RELOAD)->EnableWindow(false);
		UpdateAllData();
	}
}

void CEditConfig::OnChangeEditBaudgen() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
	// Update all data when we edit this field
	UpdateAllData();
}

void CEditConfig::OnSelchangeComboPrescaler() 
{
	// TODO: Add your control notification handler code here
	
	// Set our current prescaler to the selection
	switch (m_PrescalerList.GetCurSel())
	{
	case 0 : m_Prescaler = 1;	break;
	case 1 : m_Prescaler = 4;	break;
	case 2 : m_Prescaler = 12;	break;
	case 3 : m_Prescaler = 48;	break;
	}

	// Update all data when we edit this field
	UpdateAllData();
}

void CEditConfig::OnChangeEditT0reload() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here

	// Update all data when we edit this field
	UpdateAllData();
}
