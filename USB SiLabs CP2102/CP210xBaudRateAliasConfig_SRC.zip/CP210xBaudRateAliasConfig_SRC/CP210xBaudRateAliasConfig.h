// CP210xBaudRateAliasConfig.h : main header file for the CP210XBAUDRATEALIASCONFIG application
//

#if !defined(AFX_CP21XXBAUDRATEALIASCONFIG_H__D2F3ADD2_37B5_4449_9B48_B73A66ADBBF5__INCLUDED_)
#define AFX_CP21XXBAUDRATEALIASCONFIG_H__D2F3ADD2_37B5_4449_9B48_B73A66ADBBF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include <vector>
#include "CP210xManufacturingDLL.h"

#define CP2102_SYSCLK			48000000
#define CP2102_TIMEOUT_CLOCK	500000

//low/high baudrates
const UINT baudRange[NUM_BAUD_CONFIGS][2] = {	
								{4294967295, 2457601},
								{2457600, 1474561},
								{1474560, 1053258},
								{1053257, 670255},
								{670254, 567139},
								{567138, 491521},
								{491520, 273067},
								{273066, 254235},
								{254234, 237833},
								{237832, 156869},
								{156868, 129348},
								{129347, 117029},
								{117028, 77609},
								{77608, 64112},
								{64111, 58054},
								{58053, 56281},
								{56280, 51559},
								{51558, 38602},
								{38601, 28913},
								{28912, 19251},
								{19250, 16063},
								{16062, 14429},
								{14428, 9613},
								{9612, 7208},
								{7207, 4804},
								{4803, 4001},
								{4000, 2401},
								{2400, 1801},
								{1800, 1201},
								{1200, 601},
								{600, 301},
								{300, 57}
								};

//global functions
UINT HexStringToValue(CString s, int size);
WORD CalculateBestBaudGen(UINT sysclk, UINT br);
BYTE CalculateBestPrescaler(UINT sysclk, UINT br);
UINT CalculateBaudRate(UINT sysclk, WORD prescaler, WORD baudgen);
double CalculateActualBaudRate(UINT sysclk, WORD prescaler, WORD baudgen);
WORD CalculateBaudGen(UINT timer0sysclk, WORD prescaler, UINT br);
WORD CalculateTimer0Reload(UINT timer0sysclk, double br);
double CalculateTimeoutTime(UINT timer0sysclk, WORD reload);
WORD RoundWord(double val);
UINT RoundUint(double val);

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigApp:
// See CP210xBaudRateAliasConfig.cpp for the implementation of this class
//

class CCP210xBaudRateAliasConfigApp : public CWinApp
{
public:
	CCP210xBaudRateAliasConfigApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCP210xBaudRateAliasConfigApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCP210xBaudRateAliasConfigApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CP21XXBAUDRATEALIASCONFIG_H__D2F3ADD2_37B5_4449_9B48_B73A66ADBBF5__INCLUDED_)
