#if !defined(AFX_EDITCONFIG_H__D42154E7_6042_44F6_8647_FCBD9046B890__INCLUDED_)
#define AFX_EDITCONFIG_H__D42154E7_6042_44F6_8647_FCBD9046B890__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditConfig.h : header file
//

#define ADVANCED_HEIGHT		357
#define NO_ADVANCED_HEIGHT	145

/////////////////////////////////////////////////////////////////////////////
// CEditConfig dialog

class CEditConfig : public CDialog
{
// Construction
public:
	BOOL CompareToDefault();
	void UpdateAllData();
	void DetermineAndUpdateDefaultBaudRate(UINT sysclk, UINT br);
	void DetermineAndUpdateDefaultTimeout();
	void UpdateTimeoutTimes();
	BYTE m_Prescaler;
	CEditConfig(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditConfig)
	enum { IDD = IDD_DIALOG_EDIT_CONFIGURATION };
	CComboBox	m_PrescalerList;
	CString	m_BaudGen;
	CString	m_LineNum;
	CString	m_Timer0Reload;
	UINT	m_BaudRateDBR;
	UINT	m_BaudRateABR;
	CString	m_DefaultBaudGen;
	CString	m_DefaultPrescaler;
	CString	m_DefaultTimer0Reload;
	CString	m_DefaultTimeout;
	CString	m_Timeout;
	BOOL	m_Override;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditConfig)
	afx_msg void OnButtonAdvanced();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEditBaudrateDbr();
	afx_msg void OnCheckOverride();
	afx_msg void OnChangeEditBaudgen();
	afx_msg void OnSelchangeComboPrescaler();
	afx_msg void OnChangeEditT0reload();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITCONFIG_H__D42154E7_6042_44F6_8647_FCBD9046B890__INCLUDED_)
