// CP210xBaudRateAliasConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CP210xBaudRateAliasConfig.h"
#include "CP210xBaudRateAliasConfigDlg.h"
#include "EditConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigDlg dialog

CCP210xBaudRateAliasConfigDlg::CCP210xBaudRateAliasConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCP210xBaudRateAliasConfigDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCP210xBaudRateAliasConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCP210xBaudRateAliasConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCP210xBaudRateAliasConfigDlg)
	DDX_Control(pDX, IDC_LIST_TITLE, m_Title);
	DDX_Control(pDX, IDC_COMBO_DEVICES, m_Devices);
	DDX_Control(pDX, IDC_LIST_BAUDRATEALIAS, m_BaudRateAliasList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCP210xBaudRateAliasConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CCP210xBaudRateAliasConfigDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_GET_CONFIG, OnButtonGetConfig)
	ON_BN_CLICKED(IDC_BUTTON_SET_CONFIG, OnButtonSetConfig)
	ON_BN_CLICKED(IDC_BUTTON_RESTORE, OnButtonRestoreConfig)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_BAUDRATEALIAS, OnDblclkListBaudratealias)
	ON_BN_CLICKED(IDC_BUTTON_REFRESH, ResetDeviceList)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT, OnButtonExport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigDlg message handlers

BOOL CCP210xBaudRateAliasConfigDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here


	//All the default data for the part is initialized here
	
	m_DefaultBaudConfigData[0].BaudRate = 15000000;
	m_DefaultBaudConfigData[0].BaudGen = 0xFFF0;
	m_DefaultBaudConfigData[0].Prescaler = 1;
	m_DefaultBaudConfigData[0].Timer0Reload = 0xFFFA;

	m_DefaultBaudConfigData[1].BaudRate = 15000000;
	m_DefaultBaudConfigData[1].BaudGen = 0xFFF0;
	m_DefaultBaudConfigData[1].Prescaler = 1;
	m_DefaultBaudConfigData[1].Timer0Reload = 0xFFFA;

	m_DefaultBaudConfigData[2].BaudRate = 12000000;
	m_DefaultBaudConfigData[2].BaudGen = 0xFFEC;
	m_DefaultBaudConfigData[2].Prescaler = 1;
	m_DefaultBaudConfigData[2].Timer0Reload = 0xFFF8;

	m_DefaultBaudConfigData[3].BaudRate = 921600;
	m_DefaultBaudConfigData[3].BaudGen = 0xFFE6;
	m_DefaultBaudConfigData[3].Prescaler = 1;
	m_DefaultBaudConfigData[3].Timer0Reload = 0xFFF6;

	m_DefaultBaudConfigData[4].BaudRate = 576000;
	m_DefaultBaudConfigData[4].BaudGen = 0xFFD6;
	m_DefaultBaudConfigData[4].Prescaler = 1;
	m_DefaultBaudConfigData[4].Timer0Reload = 0xFFF0;

	m_DefaultBaudConfigData[5].BaudRate = 500000;
	m_DefaultBaudConfigData[5].BaudGen = 0xFFD0;
	m_DefaultBaudConfigData[5].Prescaler = 1;
	m_DefaultBaudConfigData[5].Timer0Reload = 0xFFEE;

	m_DefaultBaudConfigData[6].BaudRate = 460800;
	m_DefaultBaudConfigData[6].BaudGen = 0xFFCC;
	m_DefaultBaudConfigData[6].Prescaler = 1;
	m_DefaultBaudConfigData[6].Timer0Reload = 0xFFEC;

	m_DefaultBaudConfigData[7].BaudRate = 256000;
	m_DefaultBaudConfigData[7].BaudGen = 0xFFA2;
	m_DefaultBaudConfigData[7].Prescaler = 1;
	m_DefaultBaudConfigData[7].Timer0Reload = 0xFFDC;

	m_DefaultBaudConfigData[8].BaudRate = 250000;
	m_DefaultBaudConfigData[8].BaudGen = 0xFFA0;
	m_DefaultBaudConfigData[8].Prescaler = 1;
	m_DefaultBaudConfigData[8].Timer0Reload = 0xFFDC;

	m_DefaultBaudConfigData[9].BaudRate = 230400;
	m_DefaultBaudConfigData[9].BaudGen = 0xFF98;
	m_DefaultBaudConfigData[9].Prescaler = 1;
	m_DefaultBaudConfigData[9].Timer0Reload = 0xFFD9;

	m_DefaultBaudConfigData[10].BaudRate = 153600;
	m_DefaultBaudConfigData[10].BaudGen = 0xFF64;
	m_DefaultBaudConfigData[10].Prescaler = 1;
	m_DefaultBaudConfigData[10].Timer0Reload = 0xFFC5;

	m_DefaultBaudConfigData[11].BaudRate = 128000;
	m_DefaultBaudConfigData[11].BaudGen = 0xFF44; //Originally FF45 in firmware, but changed to FF44 Sep 7 2004
	m_DefaultBaudConfigData[11].Prescaler = 1;
	m_DefaultBaudConfigData[11].Timer0Reload = 0xFFB9;

	m_DefaultBaudConfigData[12].BaudRate = 115200;
	m_DefaultBaudConfigData[12].BaudGen = 0xFF30;
	m_DefaultBaudConfigData[12].Prescaler = 1;
	m_DefaultBaudConfigData[12].Timer0Reload = 0xFFB2;

	m_DefaultBaudConfigData[13].BaudRate = 76800;
	m_DefaultBaudConfigData[13].BaudGen = 0xFEC8;
	m_DefaultBaudConfigData[13].Prescaler = 1;
	m_DefaultBaudConfigData[13].Timer0Reload = 0xFF8B;

	m_DefaultBaudConfigData[14].BaudRate = 64000;
	m_DefaultBaudConfigData[14].BaudGen = 0xFE89;
	m_DefaultBaudConfigData[14].Prescaler = 1;
	m_DefaultBaudConfigData[14].Timer0Reload = 0xFF73;

	m_DefaultBaudConfigData[15].BaudRate = 57600;
	m_DefaultBaudConfigData[15].BaudGen = 0xFE5F;
	m_DefaultBaudConfigData[15].Prescaler = 1;
	m_DefaultBaudConfigData[15].Timer0Reload = 0xFF63;

	m_DefaultBaudConfigData[16].BaudRate = 56000;
	m_DefaultBaudConfigData[16].BaudGen = 0xFE53;
	m_DefaultBaudConfigData[16].Prescaler = 1;
	m_DefaultBaudConfigData[16].Timer0Reload = 0xFF5F;

	m_DefaultBaudConfigData[17].BaudRate = 51200;
	m_DefaultBaudConfigData[17].BaudGen = 0xFE2B;
	m_DefaultBaudConfigData[17].Prescaler = 1;
	m_DefaultBaudConfigData[17].Timer0Reload = 0xFF50;

	m_DefaultBaudConfigData[18].BaudRate = 38400;
	m_DefaultBaudConfigData[18].BaudGen = 0xFD8F;
	m_DefaultBaudConfigData[18].Prescaler = 1;
	m_DefaultBaudConfigData[18].Timer0Reload = 0xFF15;

	m_DefaultBaudConfigData[19].BaudRate = 28800;
	m_DefaultBaudConfigData[19].BaudGen = 0xFCBF;
	m_DefaultBaudConfigData[19].Prescaler = 1;
	m_DefaultBaudConfigData[19].Timer0Reload = 0xFEC7;

	m_DefaultBaudConfigData[20].BaudRate = 19200;
	m_DefaultBaudConfigData[20].BaudGen = 0xFB1E;
	m_DefaultBaudConfigData[20].Prescaler = 1;
	m_DefaultBaudConfigData[20].Timer0Reload = 0xFE2B;

	m_DefaultBaudConfigData[21].BaudRate = 16000;
	m_DefaultBaudConfigData[21].BaudGen = 0xFA24;
	m_DefaultBaudConfigData[21].Prescaler = 1;
	m_DefaultBaudConfigData[21].Timer0Reload = 0xFDCD;

	m_DefaultBaudConfigData[22].BaudRate = 14400;
	m_DefaultBaudConfigData[22].BaudGen = 0xF97D;
	m_DefaultBaudConfigData[22].Prescaler = 1;
	m_DefaultBaudConfigData[22].Timer0Reload = 0xFD8E;

	m_DefaultBaudConfigData[23].BaudRate = 9600;
	m_DefaultBaudConfigData[23].BaudGen = 0xF63C;
	m_DefaultBaudConfigData[23].Prescaler = 1;
	m_DefaultBaudConfigData[23].Timer0Reload = 0xFC56;

	m_DefaultBaudConfigData[24].BaudRate = 7200;
	m_DefaultBaudConfigData[24].BaudGen = 0xF2FB;
	m_DefaultBaudConfigData[24].Prescaler = 1;
	m_DefaultBaudConfigData[24].Timer0Reload = 0xFB1E;

	m_DefaultBaudConfigData[25].BaudRate = 4800;
	m_DefaultBaudConfigData[25].BaudGen = 0xEC78;
	m_DefaultBaudConfigData[25].Prescaler = 1;
	m_DefaultBaudConfigData[25].Timer0Reload = 0xF8AD;

	m_DefaultBaudConfigData[26].BaudRate = 4000;
	m_DefaultBaudConfigData[26].BaudGen = 0xE890;
	m_DefaultBaudConfigData[26].Prescaler = 1;
	m_DefaultBaudConfigData[26].Timer0Reload = 0xF736;

	m_DefaultBaudConfigData[27].BaudRate = 2400;
	m_DefaultBaudConfigData[27].BaudGen = 0xD8F0;
	m_DefaultBaudConfigData[27].Prescaler = 1;
	m_DefaultBaudConfigData[27].Timer0Reload = 0xF15A;

	m_DefaultBaudConfigData[28].BaudRate = 1800;
	m_DefaultBaudConfigData[28].BaudGen = 0xCBEB;
	m_DefaultBaudConfigData[28].Prescaler = 1;
	m_DefaultBaudConfigData[28].Timer0Reload = 0xEC78;

	m_DefaultBaudConfigData[29].BaudRate = 1200;
	m_DefaultBaudConfigData[29].BaudGen = 0xB1E0;
	m_DefaultBaudConfigData[29].Prescaler = 1;
	m_DefaultBaudConfigData[29].Timer0Reload = 0xE2B4;

	m_DefaultBaudConfigData[30].BaudRate = 600;
	m_DefaultBaudConfigData[30].BaudGen = 0x63C0;
	m_DefaultBaudConfigData[30].Prescaler = 1;
	m_DefaultBaudConfigData[30].Timer0Reload = 0xC568;

	m_DefaultBaudConfigData[31].BaudRate = 300;
	m_DefaultBaudConfigData[31].BaudGen = 0xB1E0;
	m_DefaultBaudConfigData[31].Prescaler = 4;
	m_DefaultBaudConfigData[31].Timer0Reload = 0x8AD0;

	// Setup for the header column labels
	m_Title.InsertColumn(0, "", LVCFMT_CENTER, 20);
	m_Title.InsertColumn(1, "Application Requested Baud Rate Range", LVCFMT_CENTER, 210);
	m_Title.InsertColumn(2, "UART Baud Rate", LVCFMT_CENTER, 210);

	// Setup for the main column labels
	m_BaudRateAliasList.InsertColumn(0, "#", LVCFMT_CENTER, 20);
	m_BaudRateAliasList.InsertColumn(1, "High", LVCFMT_CENTER, 105);
	m_BaudRateAliasList.InsertColumn(2, "Low", LVCFMT_CENTER, 105);
	m_BaudRateAliasList.InsertColumn(3, "Desired", LVCFMT_CENTER, 105);
	m_BaudRateAliasList.InsertColumn(4, "Actual", LVCFMT_CENTER, 105);
		
	ListView_SetExtendedListViewStyleEx(m_BaudRateAliasList.m_hWnd, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);

	// Reset the device list to obtain all connected CP210x devices
	ResetDeviceList();
	
	// Obtain the configuration of the selected item
	OnButtonGetConfig();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCP210xBaudRateAliasConfigDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCP210xBaudRateAliasConfigDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCP210xBaudRateAliasConfigDlg::ResetDeviceList()
{
	DWORD numDevices;

	// Obtain the number of devices connected
	CP210x_GetNumDevices(&numDevices);

	// Reset the content of our list
	m_Devices.ResetContent();

	// Loop through each device, and put its product string in the list
	for (DWORD i = 0; i < numDevices; i++)
	{
		CP210x_DEVICE_STRING serialString;

		CP210x_GetProductString(i, serialString, CP210x_RETURN_FULL_PATH);
		m_Devices.AddString(serialString);
	}

	// Set our list to select the first device in it
	m_Devices.SetCurSel(0);
}

void CCP210xBaudRateAliasConfigDlg::OnButtonGetConfig() 
{
	// TODO: Add your control notification handler code here
	
	// Check our current device selection
	if (m_Devices.GetCurSel() > -1)
	{
		// If we are selecting a valid device, open it
		if (CP210x_Open(m_Devices.GetCurSel(), &m_DeviceHandle) == CP210x_SUCCESS)
		{
			// Obtain the part num, only CP2102 and up will work
			BYTE version;
			if (CP210x_GetPartNumber(m_DeviceHandle, &version) == CP210x_SUCCESS)
			{
				if (version == CP210x_CP2101_VERSION)
				{
					MessageBox("CP2101 is not supported in this application", "Error", MB_OK | MB_ICONEXCLAMATION);
				}
				else
				{
					// If we have a CP2102, then get the baud config and refresh the baud config window
					CP210x_GetBaudRateConfig(m_DeviceHandle, m_BaudConfigData);
					RefreshBaudConfigList();					
				}
			}

			CP210x_Close(m_DeviceHandle);
		}
	}
}

void CCP210xBaudRateAliasConfigDlg::OnButtonSetConfig() 
{
	// TODO: Add your control notification handler code here
	
	// Check our current device selection
	if (m_Devices.GetCurSel() > -1)
	{
		// If we are selecting a valid device, open it
		if (CP210x_Open(m_Devices.GetCurSel(), &m_DeviceHandle) == CP210x_SUCCESS)
		{
			// Obtain the part num, only CP2102 and up will work
			BYTE version;
			if (CP210x_GetPartNumber(m_DeviceHandle, &version) == CP210x_SUCCESS)
			{
				if (version == CP210x_CP2101_VERSION)
				{
					MessageBox("CP2101 is not supported in this application", "Error", MB_OK | MB_ICONEXCLAMATION);
				}
				else
				{
					if (MessageBox("Are you sure you want to set the current baud rate configuration to the part seleceted?", "Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
					{
						// Set the baud config data on the part, then immediately read the data back
						// and refresh the baud config window
						CP210x_SetBaudRateConfig(m_DeviceHandle, m_BaudConfigData);
						CP210x_GetBaudRateConfig(m_DeviceHandle, m_BaudConfigData);
						RefreshBaudConfigList();
					}
				}
			}

			CP210x_Close(m_DeviceHandle);
		}
	}
}

void CCP210xBaudRateAliasConfigDlg::OnButtonRestoreConfig() 
{
	// TODO: Add your control notification handler code here
	
	// Check our current device selection
	if (m_Devices.GetCurSel() > -1)
	{
		// If we are selecting a valid device, open it
		if (CP210x_Open(m_Devices.GetCurSel(), &m_DeviceHandle) == CP210x_SUCCESS)
		{
			// Obtain the part num, only CP2102 and up will work
			BYTE version;
			if (CP210x_GetPartNumber(m_DeviceHandle, &version) == CP210x_SUCCESS)
			{
				if (version == CP210x_CP2101_VERSION)
				{
					MessageBox("CP2101 is not supported in this application", "Error", MB_OK | MB_ICONEXCLAMATION);
				}
				else
				{
					// Prompt to see if they want to destroy all current data and return to default
					if (MessageBox("Restoring will set each baud rate configuration back to default, are you sure?", "Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
					{
						// If so, then set the default data back to the part, and immediatly read
						// and update the baud config window
						CP210x_SetBaudRateConfig(m_DeviceHandle, m_DefaultBaudConfigData);
						CP210x_GetBaudRateConfig(m_DeviceHandle, m_BaudConfigData);
						RefreshBaudConfigList();
					}
				}
			}

			CP210x_Close(m_DeviceHandle);
		}
	}
}

void CCP210xBaudRateAliasConfigDlg::OnDblclkListBaudratealias(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	// Get the line selected
	int selectedLine = m_BaudRateAliasList.GetNextItem(-1, LVNI_SELECTED);

	// Make sure the line is valid
	if (selectedLine != -1)
	{
		CEditConfig	editConfig;
		
		// Add 3 since we skipped the first three baud rates
		selectedLine += 3;

		// Set the "user field" members of our editConfig dlg class, the
		// default data will be set automaticall from the desired baud rate
		editConfig.m_LineNum.Format("Baud Range: %d to %d", baudRange[selectedLine][1], baudRange[selectedLine][0]);
		editConfig.m_BaudGen.Format("%04X", m_BaudConfigData[selectedLine].BaudGen);
		editConfig.m_Timer0Reload.Format("%04X", m_BaudConfigData[selectedLine].Timer0Reload);
		editConfig.m_Prescaler =	m_BaudConfigData[selectedLine].Prescaler;
		editConfig.m_BaudRateDBR =	m_BaudConfigData[selectedLine].BaudRate;

		// Determine if the "desired baud rate" has been overridden with some other data
		if (!((CalculateBestBaudGen(CP2102_SYSCLK, m_BaudConfigData[selectedLine].BaudRate) == m_BaudConfigData[selectedLine].BaudGen) &&
			(CalculateBestPrescaler(CP2102_SYSCLK, m_BaudConfigData[selectedLine].BaudRate) == m_BaudConfigData[selectedLine].Prescaler) &&
			(CalculateTimer0Reload(CP2102_TIMEOUT_CLOCK, CalculateActualBaudRate(CP2102_SYSCLK, m_BaudConfigData[selectedLine].Prescaler, m_BaudConfigData[selectedLine].BaudGen)) == m_BaudConfigData[selectedLine].Timer0Reload)))
		{
			editConfig.m_Override = true;
		}

		// Show the window
		if (editConfig.DoModal() == IDOK)
		{
			// If ok is pressed, then store all of the data from the window into our baud config array
			m_BaudConfigData[selectedLine].BaudGen = HexStringToValue(editConfig.m_BaudGen, 4);
			m_BaudConfigData[selectedLine].Timer0Reload = HexStringToValue(editConfig.m_Timer0Reload, 4);
			m_BaudConfigData[selectedLine].Prescaler = editConfig.m_Prescaler;
			m_BaudConfigData[selectedLine].BaudRate = editConfig.m_BaudRateDBR;
					
			// Refresh the baud config window
			RefreshBaudConfigList();
		}
	}

	*pResult = 0;
}

void CCP210xBaudRateAliasConfigDlg::RefreshBaudConfigList()
{
	CString tmp;

	// Clear any previous data from the window
	m_BaudRateAliasList.DeleteAllItems();

	// Loop through each baud config, and display them in the list
	// Format:   #    highrange    lowrange    desiredbaud    actualbaud

	// Note that we are starting at 2, this is to clear the top 3 baud rates
	// since they normally will not need to be aliased
	for (int i = 2; i < NUM_BAUD_CONFIGS; i++)
	{
		// Config number
		tmp.Format("%d", i-3);
		m_BaudRateAliasList.InsertItem(i-3, tmp);

		// High baud range
		tmp.Format("%u", baudRange[i][0]);
		m_BaudRateAliasList.SetItemText(i-3, 1, tmp);

		// Low baud range
		tmp.Format("%u", baudRange[i][1]);
		m_BaudRateAliasList.SetItemText(i-3, 2, tmp);

		// Desired baud rate
		tmp.Format("%u", m_BaudConfigData[i].BaudRate);
		m_BaudRateAliasList.SetItemText(i-3, 3, tmp);

		// Actual baud rate (calculated)
		tmp.Format("%u", CalculateBaudRate(CP2102_SYSCLK, m_BaudConfigData[i].Prescaler, m_BaudConfigData[i].BaudGen));
		m_BaudRateAliasList.SetItemText(i-3, 4, tmp);
	}
}

void CCP210xBaudRateAliasConfigDlg::OnButtonExport() 
{
	try
	{
		// Check our current device selection
		if (m_Devices.GetCurSel() > -1)
		{
			CFileDialog fileDlg(FALSE, "hex", "CP210xBaudConfig.hex", NULL, "Hex Files (*.hex)|*.hex|All Files (*.*)|*.*||", this);

			if (fileDlg.DoModal() == IDOK)
			{
				CString fileName = fileDlg.GetPathName();

				// If we are selecting a valid device, open it
				if (CP210x_Open(m_Devices.GetCurSel(), &m_DeviceHandle) == CP210x_SUCCESS)
				{
					if (CP210x_CreateHexFile(m_DeviceHandle, fileName) != CP210x_SUCCESS)
						MessageBox("Could not create file");

					CP210x_Close(m_DeviceHandle);
				}
			}
		}
	}
	catch (...)
	{
	}
}

