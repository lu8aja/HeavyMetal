//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CP210xBaudRateAliasConfig.rc
//
#define IDD_CP210XBAUDRATEALIASCONFIG_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_EDIT_CONFIGURATION   129
#define IDC_LIST_BAUDRATEALIAS          1000
#define IDC_COMBO_DEVICES               1001
#define IDC_BUTTON_REFRESH              1002
#define IDC_BUTTON_GET_CONFIG           1003
#define IDC_BUTTON_SET_CONFIG           1004
#define IDC_EDIT_BAUDGEN                1005
#define IDC_BUTTON_EXPORT               1005
#define IDC_EDIT_T0RELOAD               1006
#define IDC_EDIT_BAUDRATE_BR            1007
#define IDC_EDIT_BAUDRATE_DBR           1008
#define IDC_EDIT_BAUDRATE_ABR           1009
#define IDC_BUTTON_ADVANCED             1010
#define IDC_EDIT_DEFAULTBAUDGEN         1011
#define IDC_EDIT_DEFAULTT0RELOAD        1012
#define IDC_EDIT_DEFAULTPRESCALER       1013
#define IDC_CHECK_OVERRIDE              1014
#define IDC_EDIT_DEFAULTTIMEOUT         1015
#define IDC_EDIT_TIMEOUT                1016
#define IDC_COMBO_PRESCALER             1017
#define IDC_STATIC_LINENUM              1018
#define IDC_BUTTON_RESTORE              1019
#define IDC_LIST_TITLE                  1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
