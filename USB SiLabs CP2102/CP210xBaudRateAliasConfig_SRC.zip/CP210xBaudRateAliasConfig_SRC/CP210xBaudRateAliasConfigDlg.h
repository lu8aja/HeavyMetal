// CP210xBaudRateAliasConfigDlg.h : header file
//

#if !defined(AFX_CP21XXBAUDRATEALIASCONFIGDLG_H__DDDC9DC8_9408_4C9C_991C_AC56EF40F631__INCLUDED_)
#define AFX_CP21XXBAUDRATEALIASCONFIGDLG_H__DDDC9DC8_9408_4C9C_991C_AC56EF40F631__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCP210xBaudRateAliasConfigDlg dialog

class CCP210xBaudRateAliasConfigDlg : public CDialog
{
// Construction
public:
	HANDLE	m_DeviceHandle;
	BAUD_CONFIG_DATA	m_BaudConfigData;
	BAUD_CONFIG_DATA	m_DefaultBaudConfigData;

	void ResetDeviceList();
	void RefreshBaudConfigList();

	CCP210xBaudRateAliasConfigDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCP210xBaudRateAliasConfigDlg)
	enum { IDD = IDD_CP210XBAUDRATEALIASCONFIG_DIALOG };
	CListCtrl	m_Title;
	CComboBox	m_Devices;
	CListCtrl	m_BaudRateAliasList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCP210xBaudRateAliasConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCP210xBaudRateAliasConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonGetConfig();
	afx_msg void OnButtonSetConfig();
	afx_msg void OnButtonRestoreConfig();
	afx_msg void OnDblclkListBaudratealias(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonExport();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CP21XXBAUDRATEALIASCONFIGDLG_H__DDDC9DC8_9408_4C9C_991C_AC56EF40F631__INCLUDED_)
